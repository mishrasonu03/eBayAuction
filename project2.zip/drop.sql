DROP TABLE IF EXISTS Bids, Category, Items, Sellers, Bidders, Users;
